source('methods.R')
d<-readRDS('data/development.rds');x<-readRDS('data/evaluation-features.rds')
stopifnot(!any(c('delay','missing_outcomes')%in%names(x)),max(d$date)<min(x$date))
b<-read.csv('results/leaderboard.csv')
no<-filter(b,set%in%c('Schedule','Baseline'))%>%arrange(RMSE,id)%>%slice_head(n=1)
yes<-filter(b,set=='Weather')%>%arrange(RMSE,id)%>%slice_head(n=1)
fs<-filter(b,set=='Schedule',family=='Forest');fw<-filter(b,set=='Weather',family=='Forest')
choices<-bind_rows(mutate(no,role='No weather'),mutate(yes,role='Morning weather'),mutate(fs,role='Forest without weather'),mutate(fw,role='Forest with weather'))
write.csv(choices,'results/selection-lock.csv',row.names=FALSE)
p<-select(x,origin,date)
for(i in 1:nrow(choices)){
 cfg<-choices[i,]
 if(cfg$set=='Baseline') {ab<-prep(d,x,features_for('Schedule'));pred<-baselines(ab$a,ab$b)[[cfg$family]]}
 else pred<-fit_predict(cfg,d,x,cfg$set,seed=2422024)
 p[[cfg$role]]<-pred
}
write.csv(p,'results/locked-predictions.csv',row.names=FALSE)
writeLines(c(paste('protocol',tools::md5sum('PROTOCOL.md')),paste('selection',tools::md5sum('results/selection-lock.csv')),
 paste('predictions',tools::md5sum('results/locked-predictions.csv'))),'results/before-evaluation-hashes.txt')
cat('Locked choices and predictions without reading future outcome file.\n');print(choices)
