source('methods.R')
d<-readRDS('data/development.rds')
ends<-as.Date(c('2023-03-31','2023-05-31','2023-07-31','2023-09-30'))
stops<-as.Date(c('2023-05-31','2023-07-31','2023-09-30','2023-12-31'))
registry<-list();results<-list();predictions<-list();ii<-0;pp<-0
record<-function(cfg,set,fold,a,b,p,pt){
 ii<<-ii+1;results[[ii]]<<-tibble(id=cfg$id,set=set,family=cfg$family,fold=fold,n=nrow(b),sse=sum((b$delay-p)^2),sae=sum(abs(b$delay-p)),train_n=nrow(a),train_sse=sum((a$delay-pt)^2))
 pp<<-pp+1;predictions[[pp]]<<-tibble(id=cfg$id,set=set,fold=fold,origin=b$origin,date=b$date,observed=b$delay,predicted=p)
}
for(set in c('Schedule','Weather')){
 features<-features_for(set)
 reg<-bind_rows(expand_grid(alpha=c(0,.25,.5,.75,1),lambda=10^seq(6,-3,length.out=61))%>%mutate(family=case_when(alpha==0~'Ridge',alpha==1~'LASSO',TRUE~'Elastic net')),
 expand_grid(depth=c(1:15,20,25,30),leaf=c(5,10,20,40))%>%mutate(family='Tree'),
 expand_grid(mtry=unique(c(1,3,6,length(features))),leaf=c(1,5,15,30,60,120,270))%>%mutate(family='Forest'),
 tibble(k=c(3,5,10,20,40,80,120,160,240),family='KNN'))%>%mutate(id=row_number(),set=set)
 registry[[set]]<-reg
 for(fold in 1:4){
  a<-filter(d,date<=ends[fold]);b<-filter(d,date>ends[fold],date<=stops[fold]);stopifnot(max(a$date)<min(b$date))
  p<-prep(a,b,features);a<-p$a;b<-p$b
  if(set=='Schedule'){bp<-baselines(a,b);bt<-baselines(a,a)
   for(n in names(bp))record(list(id=-match(n,names(bp)),family=n),'Baseline',fold,a,b,bp[[n]],bt[[n]])}
  m<-matrices(a,b,features,TRUE)
  for(al in c(0,.25,.5,.75,1)){
   cfg<-filter(reg,!is.na(alpha),alpha==al)%>%arrange(desc(lambda))
   fit<-glmnet(m$x,a$delay,alpha=al,lambda=cfg$lambda,standardize=FALSE)
   pv<-predict(fit,m$z,s=cfg$lambda);pt<-predict(fit,m$x,s=cfg$lambda)
   for(j in 1:nrow(cfg))record(cfg[j,],set,fold,a,b,pv[,j],pt[,j])
  }
  m<-matrices(a,b,features);ks<-filter(reg,family=='KNN')
  nn<-FNN::get.knnx(m$x,m$z,k=max(ks$k))$nn.index;nt<-FNN::get.knnx(m$x,m$x,k=max(ks$k))$nn.index
  for(j in 1:nrow(ks)){k<-ks$k[j];pv<-rowMeans(matrix(a$delay[nn[,1:k,drop=FALSE]],nrow=nrow(b)));pt<-rowMeans(matrix(a$delay[nt[,1:k,drop=FALSE]],nrow=nrow(a)));record(ks[j,],set,fold,a,b,pv,pt)}
  for(j in which(reg$family%in%c('Tree','Forest'))){cfg<-reg[j,];f<-reformulate(features,response='delay')
   if(cfg$family=='Tree'){fit<-rpart(f,data=a,method='anova',control=rpart.control(cp=0,maxdepth=cfg$depth,minbucket=cfg$leaf,minsplit=2*cfg$leaf,xval=0));pv<-predict(fit,b);pt<-predict(fit,a)}else{
    fit<-ranger(f,data=a,num.trees=500,mtry=cfg$mtry,min.node.size=cfg$leaf,respect.unordered.factors='order',seed=242+fold,num.threads=2);pv<-predict(fit,b)$predictions;pt<-predict(fit,a)$predictions}
   record(cfg,set,fold,a,b,pv,pt)
  }
  cat(set,'forward fold',fold,'complete\n');flush.console()
 }
}
reg<-bind_rows(registry);raw<-bind_rows(results);pr<-bind_rows(predictions)
score<-raw%>%group_by(set,id,family)%>%summarize(RMSE=sqrt(sum(sse)/sum(n)),MAE=sum(sae)/sum(n),train_RMSE=sqrt(sum(train_sse)/sum(train_n)),.groups='drop')%>%left_join(select(reg,-family),by=c('set','id'))%>%arrange(RMSE)
board<-score%>%group_by(set,family)%>%slice_min(RMSE,n=1,with_ties=FALSE)%>%ungroup()
chosen<-board%>%group_by(set)%>%slice_min(RMSE,n=1,with_ties=FALSE)%>%ungroup()
write.csv(reg,'results/configurations.csv',row.names=FALSE);write.csv(raw,'results/fold-scores.csv',row.names=FALSE)
write.csv(score,'results/cv-grid.csv',row.names=FALSE);write.csv(board,'results/leaderboard.csv',row.names=FALSE)
write.csv(chosen,'results/selected.csv',row.names=FALSE);write.csv(pr,'results/validation-predictions.csv',row.names=FALSE)
write.csv(tibble(train_end=ends,validation_end=stops),'results/forward-folds.csv',row.names=FALSE)
print(chosen);print(board)
