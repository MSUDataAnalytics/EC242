At 09:00, can morning weather improve predictions of afternoon departure
delay? The report uses 2023 for forward validation and January 2024 for
a locked future evaluation. The rendered report reads audited results;
document changes cannot silently change the selected model or evaluation
sample.

    m <- jsonlite::read_json('results/evaluation-summary.json')
    stopifnot(is.finite(m$model_rmse))
    python <- Sys.getenv('PYTHON', unset=Sys.which('python3'))
    output <- if(params$show_code) 'example-with-code.pdf' else 'example-memo.pdf'
    stopifnot(system2(python,c('report.py','--output',output,
                             if(params$show_code)'--code'))==0)

The vector renderer supplies identical report pages in both editions.
When code is on, it appends the complete analysis and rendering scripts
with line numbers. All raw data and computed results are supplied in the
source archive.
