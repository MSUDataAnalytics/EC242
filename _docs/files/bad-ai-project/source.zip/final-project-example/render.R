for(show in c(FALSE,TRUE))rmarkdown::render('example.Rmd',params=list(show_code=show),quiet=TRUE,
 output_file=if(show)'example-with-code.md' else 'example-memo.md',envir=new.env(parent=globalenv()))
writeLines(capture.output(sessionInfo()),'session-info.txt')
