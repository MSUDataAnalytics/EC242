# Reproduce the registered experiment; this is not a new unopened evaluation.
for(script in c('prepare.R','select.R','lock.R','evaluate.R','describe.R','finish.R','render.R')){
 cat('Running',script,'\n')
 stopifnot(system2(file.path(R.home('bin'),'Rscript'),c('--vanilla',script))==0)
}
