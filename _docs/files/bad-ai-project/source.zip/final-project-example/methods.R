suppressPackageStartupMessages({library(tidyverse);library(glmnet);library(rpart);library(ranger);library(FNN)})
base_nums<-c('scheduled','distance','longhaul','evening','share_ua','share_b6','share_dl','sin_year','cos_year')
weather_nums<-c('temp','humidity','wind','wind_max','rain','rain_max','visibility','visibility_min','pressure','weather_hours','weather_missing')
features_for<-function(set)c('origin','weekday',base_nums,if(set=='Weather')weather_nums)
prep<-function(a,b,features){for(v in setdiff(features,c('origin','weekday'))){m<-median(a[[v]],na.rm=TRUE);if(!is.finite(m))m<-0;a[[v]][is.na(a[[v]])]<-m;b[[v]][is.na(b[[v]])]<-m};list(a=a,b=b)}
matrices<-function(a,b,features,rich=FALSE){
 x<-model.matrix(reformulate(features),a)[,-1,drop=FALSE];z<-model.matrix(reformulate(features),b)[,-1,drop=FALSE]
 if(rich){ns<-setdiff(features,c('origin','weekday','weather_missing'))
  for(i in seq_along(ns))for(j in i:length(ns)){x<-cbind(x,a[[ns[i]]]*a[[ns[j]]]);z<-cbind(z,b[[ns[i]]]*b[[ns[j]]])}
  for(ap in c('JFK','LGA'))for(v in ns){x<-cbind(x,(a$origin==ap)*a[[v]]);z<-cbind(z,(b$origin==ap)*b[[v]])}
 }
 mu<-colMeans(x);sdv<-apply(x,2,sd);ok<-is.finite(sdv)&sdv>1e-8
 list(x=sweep(sweep(x[,ok,drop=FALSE],2,mu[ok]),2,sdv[ok],'/'),z=sweep(sweep(z[,ok,drop=FALSE],2,mu[ok]),2,sdv[ok],'/'))
}
group_pred<-function(a,b,keys){key<-function(x)do.call(paste,c(x[keys],sep='|'));t<-tapply(a$delay,key(a),mean);p<-as.numeric(t[key(b)]);p[is.na(p)]<-mean(a$delay);p}
ols<-function(a,b){f<-reformulate(features_for('Schedule'));x<-model.matrix(f,a);z<-model.matrix(f,b);q<-qr(x);ok<-q$pivot[seq_len(q$rank)];as.numeric(z[,ok,drop=FALSE]%*%lm.fit(x[,ok,drop=FALSE],a$delay)$coefficients)}
baselines<-function(a,b)list('Global mean'=rep(mean(a$delay),nrow(b)),'Airport mean'=group_pred(a,b,'origin'),
 'Airport-weekday'=group_pred(a,b,c('origin','weekday')),'Schedule OLS'=ols(a,b))
fit_predict<-function(cfg,a,b,set,seed=242){
 features<-features_for(set);p<-prep(a,b,features);a<-p$a;b<-p$b;f<-reformulate(features,response='delay')
 family<-cfg$family
 if(family%in%c('Ridge','LASSO','Elastic net')){m<-matrices(a,b,features,TRUE);fit<-glmnet(m$x,a$delay,alpha=cfg$alpha,lambda=cfg$lambda,standardize=FALSE);return(as.numeric(predict(fit,m$z,s=cfg$lambda)))}
 if(family=='KNN'){m<-matrices(a,b,features);return(FNN::knn.reg(m$x,m$z,a$delay,k=cfg$k)$pred)}
 if(family=='Tree'){fit<-rpart(f,data=a,method='anova',control=rpart.control(cp=0,maxdepth=cfg$depth,minbucket=cfg$leaf,minsplit=2*cfg$leaf,xval=0));return(as.numeric(predict(fit,b)))}
 fit<-ranger(f,data=a,num.trees=500,mtry=cfg$mtry,min.node.size=cfg$leaf,respect.unordered.factors='order',seed=seed,num.threads=2)
 predict(fit,b)$predictions
}
