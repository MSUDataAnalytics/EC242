"""Publication-style vector report. Charts use only saved, audited analysis exports."""
from pathlib import Path
import csv,json,math,calendar,datetime,textwrap,argparse
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
ROOT=Path(__file__).resolve().parent; D=ROOT/'results'
def rows(n):return list(csv.DictReader((D/n).open()))
def val(z,k):return float(z[k])
def read(n):return json.loads((D/n).read_text())
A=read('data-audit.json');M=read('evaluation-summary.json');F=read('findings.json')
DEV=rows('development-visuals.csv');CON=rows('weather-contrasts.csv');EV=rows('evaluation.csv')
BOARD=rows('leaderboard.csv');GRID=rows('cv-grid.csv');FORWARD=rows('forward-comparison.csv');AIR=rows('airport-errors.csv');WORST=rows('worst-errors.csv')
INK='#152A36';MUTED='#667680';PAPER='#FCFBF7';BLUE='#176EAD';TEAL='#007F76';ORANGE='#C6512C';LINE='#D9DEDD';PALE='#E8EFEE';WHITE='#FFFFFF'
for name,file,fallback in [('Sans','Arial.ttf','Helvetica'),('Bold','Arial Bold.ttf','Helvetica-Bold'),('Serif','Georgia.ttf','Times-Roman'),('Mono','Courier New.ttf','Courier')]:
 p=Path('/System/Library/Fonts/Supplemental')/file
 if p.exists():pdfmetrics.registerFont(TTFont(name,str(p)))
 else:pdfmetrics.registerFont(pdfmetrics.Font(name,fallback,'WinAnsiEncoding'))
pdfmetrics.registerFontFamily('Sans',normal='Sans',bold='Bold',italic='Sans',boldItalic='Bold')
class Report:
 def __init__(self,path):
  self.c=canvas.Canvas(str(path),pagesize=(612,792),pageCompression=1);self.page=0
  self.c.setTitle('The 9 a.m. forecast | Morning weather meets a future test')
  self.c.setAuthor('EC242 | Instructor-created example');self.c.setSubject('Forward validation, weather ablation, and a locked January 2024 evaluation')
 def rect(self,x,y,w,h,c):self.c.setFillColor(HexColor(c));self.c.rect(x,792-y-h,w,h,fill=1,stroke=0)
 def line(self,x,y,u,v,c=LINE,width=.6,dash=None):
  self.c.setStrokeColor(HexColor(c));self.c.setLineWidth(width);self.c.setDash(dash or []);self.c.line(x,792-y,u,792-v);self.c.setDash([])
 def text(self,x,y,t,size=10,font='Sans',c=INK,align='left'):
  self.c.setFillColor(HexColor(c));self.c.setFont(font,size)
  {'left':self.c.drawString,'right':self.c.drawRightString,'center':self.c.drawCentredString}[align](x,792-y-size*.82,str(t))
 def para(self,x,y,w,t,size=10,leading=14,c=INK,limit=200):
  p=Paragraph(t,ParagraphStyle('p',fontName='Sans',fontSize=size,leading=leading,textColor=HexColor(c)))
  _,h=p.wrap(w,740);assert h<=limit,(self.page,y,h,limit,t[:60]);assert y+h<746,(self.page,y,h)
  p.drawOn(self.c,x,792-y-h);return y+h
 def dot(self,x,y,r=3,c=TEAL,hollow=False):
  self.c.setFillColor(HexColor(PAPER if hollow else c));self.c.setStrokeColor(HexColor(c));self.c.setLineWidth(1.1);self.c.circle(x,792-y,r,stroke=int(hollow),fill=1)
 def start(self,section):
  if self.page:self.c.showPage()
  self.page+=1;self.rect(0,0,612,792,PAPER);self.rect(36,24,17,4,ORANGE)
  self.text(62,20,'EC242 / INSTRUCTOR-CREATED EXAMPLE',7.5,'Bold');self.text(576,20,section.upper(),7.5,'Sans',MUTED,'right');self.line(36,42,576,42)
  self.c.bookmarkPage(str(self.page));self.c.addOutlineEntry(section,str(self.page),0)
  self.line(36,751,576,751);self.text(36,764,'THE 9 A.M. FORECAST',7,'Bold',MUTED);self.text(528,764,'NYC / 2023-24',7,'Sans',MUTED,'right');self.text(576,759,f'{self.page:02}',13,'Bold',ORANGE,'right')
 def title(self,k,t,sub):
  self.text(36,62,k,8,'Bold',ORANGE);self.text(36,84,t,min(29,29*540/pdfmetrics.stringWidth(t,'Serif',29)),'Serif');self.para(36,127,540,sub,10,14,limit=58)
 def note(self,y,t):self.para(36,y,540,t,8,11,MUTED,limit=55)
 def save(self):self.c.save()

def opening(r):
 r.start('Question + data')
 r.text(36,64,'AN AIRPORT-DAY FORECAST, BUILT BEFORE LUNCH',8,'Bold',ORANGE)
 r.text(36,90,'The 9 a.m. forecast',40,'Serif')
 r.para(36,153,540,'Can morning weather help airport planners anticipate afternoon departure delays? We combine flight schedules with weather recorded before 8 a.m., predict the mean delay of flights scheduled from noon onward, and test the model on a later month. Weather cuts validation error by <b>12.3%</b> in 2023. In January 2024, that advantage disappears. A few severe days overwhelm the forecast.',11,15.5,limit=80)
 # A genuine information boundary: observed inputs, forecast issued, target window.
 r.rect(36,252,540,139,INK)
 r.text(52,268,'THE CLOCK IS PART OF THE MODEL',8,'Bold','#B6C9CE')
 x=lambda h:57+h/24*499
 r.rect(x(0),306,x(8)-x(0),16,TEAL);r.rect(x(8),306,x(9)-x(8),16,'#527078');r.rect(x(12),306,x(24)-x(12),16,ORANGE)
 r.line(x(9),298,x(9),345,'#FFFFFF',1.2)
 for h,t in [(0,'00:00'),(8,'08:00'),(12,'12:00'),(24,'24:00')]:r.text(x(h),288,t,8,'Bold',WHITE,'right' if h==24 else 'left')
 r.text(57,336,'Observed weather',9,'Bold',WHITE);r.text(x(12),336,'Flights we predict',9,'Bold',WHITE)
 r.text(52,365,'09:00 / ISSUE FORECAST',8,'Bold','#D4E2E3');r.text(560,365,'A one-hour weather reporting buffer',8,'Sans','#D4E2E3','right')
 r.text(36,418,'Data',17,'Serif')
 r.para(36,447,259,'We combine <b>BTS flight records</b> with <b>Iowa Environmental Mesonet weather observations</b>. The 2023 flights come through nycflights23; January 2024 comes directly from BTS. Both use the same reporting-carrier definitions and contain the same 14 carriers. We aggregate each source by airport and local date, then check a one-to-one join. The panel contains <b>1,188 airport-days</b>: 1,095 for development and 93 for the future test.',9.4,12.6,limit=145)
 r.para(317,447,259,'The outcome includes early departures and averages only recorded delays. Of 262,528 scheduled afternoon flights in development, <b>8,180 lack a delay outcome</b>; they remain in schedule counts. Development mean delay is <b>21.1 minutes</b>, versus a median of <b>12.8</b>. Weather is available for every airport-day; missing individual readings use training-only medians. Trace rain remains a small positive amount. No afternoon weather enters the forecast.',9.4,12.6,limit=145)
 r.line(36,600,576,600)
 for x,n,l in [(36,'1,095','DEVELOPMENT AIRPORT-DAYS'),(222,'93','FUTURE AIRPORT-DAYS'),(408,'08:00','WEATHER CUTOFF')]:
  r.text(x,617,n,30,'Bold',TEAL);r.text(x,657,l,7.2,'Bold',MUTED)
 r.note(689,'Schedules are reconstructed from final records, so historical schedule revisions and feed latency remain untested. Missing delay outcomes, including cancellations, are a separate operational risk. January supplies 7.8% of the combined panel.')
 r.text(36,732,'Sources: BTS / nycflights23 / Iowa Environmental Mesonet',7,'Sans',BLUE)
 r.c.linkURL('https://www.transtats.bts.gov/PREZIP/',(36,51,160,63),relative=0)
 r.c.linkURL('https://moderndive.github.io/nycflights23/',(160,51,270,63),relative=0)
 r.c.linkURL('https://mesonet.agron.iastate.edu/request/download.phtml',(270,51,576,63),relative=0)

def shade(value):
 # Monotone light-to-dark palette; the legend explicitly caps high values.
 t=max(0,min(1,value/90));stops=[(0,(239,242,236)),(.3,(151,191,191)),(.65,(41,120,140)),(1,(19,47,74))]
 for (a,c),(b,d) in zip(stops,stops[1:]):
  if a<=t<=b:
   q=(t-a)/(b-a);return '#'+''.join(f'{round(u+(v-u)*q):02x}' for u,v in zip(c,d))
 return '#132F4A'

def patterns(r):
 r.start('Patterns in development')
 r.title('01 / SEASON AND WEATHER','Bad mornings are not the whole story.','Delay clusters in summer, including days without low visibility or strong morning wind. Weather matters differently across airports and seasons.')
 r.text(36,187,'Every afternoon in 2023',13,'Bold');r.text(576,191,'Mean departure delay, minutes',8,'Sans',MUTED,'right')
 for j,ap in enumerate(['EWR','JFK','LGA']):
  x0=57+j*182;y0=242;cw=12.2;ch=5.2
  r.text(x0,216,ap,12,'Bold')
  for m in range(1,13):r.text(x0+(m-.5)*cw,233,calendar.month_abbr[m][0],6.8,'Sans',MUTED,'center')
  for day in [1,10,20,31]:r.text(x0-7,y0+(day-1)*ch,str(day),6.5,'Sans',MUTED,'right')
  for z in [a for a in DEV if a['origin']==ap]:
   dt=datetime.date.fromisoformat(z['date']);r.rect(x0+(dt.month-1)*cw,y0+(dt.day-1)*ch,cw-.9,ch-.7,shade(val(z,'delay')))
 for i,t in enumerate([0,15,30,60,90]):r.rect(171+i*48,421,19,8,shade(t));r.text(194+i*48,420,'90+' if t==90 else ('≤0' if t==0 else str(t)),7,'Sans',MUTED)
 r.text(36,420,'KEY',7,'Bold',MUTED)
 r.text(36,460,'Within the same airport and quarter',13,'Bold')
 r.text(36,482,'Mean afternoon delay: other mornings ○  →  low visibility / high wind ●',8.5,'Sans',MUTED)
 # Twelve comparisons share the same 0-60-minute scale; never hide reversals.
 for j,ap in enumerate(['EWR','JFK','LGA']):
  yy=524+j*53;r.text(36,yy+3,ap,11,'Bold')
  for k,q in enumerate(['Q1','Q2','Q3','Q4']):
   x0=109+k*117;xx=lambda v:x0+v/60*90
   a=next(z for z in CON if z['origin']==ap and z['quarter']==q and z['rough']=='FALSE')
   b=next(z for z in CON if z['origin']==ap and z['quarter']==q and z['rough']=='TRUE')
   if j==0:r.text(x0+45,506,q,8,'Bold',MUTED,'center')
   r.line(xx(0),yy+10,xx(60),yy+10,LINE,1)
   r.line(xx(val(a,'mean')),yy+10,xx(val(b,'mean')),yy+10,ORANGE,1.8)
   r.dot(xx(val(a,'mean')),yy+10,3.2,TEAL,True);r.dot(xx(val(b,'mean')),yy+10,3.2,ORANGE)
   r.text(x0,yy+24,f"{val(a,'mean'):.0f} → {val(b,'mean'):.0f} min",7.5,'Bold')
   r.text(x0+96,yy+24,f"n={b['n']}",7,'Sans',MUTED,'right')
 r.note(689,'Weather flag: minimum pre-8 a.m. visibility below 3 miles or maximum wind at least 20 knots. Counts show flagged mornings; some cells are small. Mean delay is higher in 10 of 12 comparisons, not all 12. These are descriptive associations, not causal estimates.')

def validation(r):
 r.start('What weather adds')
 r.title('02 / PAIRED FORWARD COMPARISONS','Give weather a fair test.','Tune each method twice: once with calendar and schedule inputs, then with those inputs plus morning weather. Both versions predict the same later dates.')
 r.text(36,184,'The validation clock only moves forward',13,'Bold')
 x0,x1=170,576;xx=lambda m:x0+(m-1)/12*(x1-x0)
 for i,(end,last) in enumerate([(3,5),(5,7),(7,9),(9,12)]):
  y=216+i*24;r.text(36,y+3,f'ROUND {i+1}',7.5,'Bold',MUTED);r.rect(xx(1),y,xx(end+1)-xx(1)-2,13,INK);r.rect(xx(end+1),y,xx(last+1)-xx(end+1)-2,13,ORANGE)
 for m in range(1,13):r.text(xx(m)+11,318,calendar.month_abbr[m][0],7,'Sans',MUTED,'center')
 r.rect(36,318,10,6,INK);r.text(51,316,'Train',7,'Sans',MUTED);r.rect(94,318,10,6,ORANGE);r.text(109,316,'Validate',7,'Sans',MUTED)
 r.text(36,357,'Weather helps more than changing the algorithm.',13,'Bold')
 r.text(36,381,'Pooled forward-validation RMSE, minutes • lower is better',8.5,'Sans',MUTED)
 xx=lambda v:230+(v-24)/9*300
 for t in [24,26,28,30,32]:r.line(xx(t),415,xx(t),586);r.text(xx(t),599,str(t),8,'Sans',MUTED,'center')
 for i,fam in enumerate(['Forest','Tree','LASSO','Elastic net','Ridge','KNN']):
  y=420+i*31;a=next(z for z in BOARD if z['set']=='Schedule' and z['family']==fam);b=next(z for z in BOARD if z['set']=='Weather' and z['family']==fam)
  r.text(36,y-5,'Random forest' if fam=='Forest' else fam,10,'Bold' if i==0 else 'Sans')
  r.line(xx(val(a,'RMSE')),y,xx(val(b,'RMSE')),y,TEAL,2)
  r.dot(xx(val(a,'RMSE')),y,4,MUTED,True);r.dot(xx(val(b,'RMSE')),y,4,TEAL)
  r.text(xx(val(b,'RMSE'))-9,y-4,f"{val(b,'RMSE'):.2f}",8,'Bold',TEAL,'right')
  r.text(xx(val(a,'RMSE'))+9,y-4,f"{val(a,'RMSE'):.2f}",8,'Sans',MUTED)
 r.text(230,622,'● Morning weather',8,'Bold',TEAL);r.text(386,622,'○ Calendar + schedule only',8,'Sans',MUTED)
 r.para(36,648,540,'The strongest no-weather choice is the airport average: <b>29.84 minutes RMSE</b>. The weather forest lowers that to <b>26.18</b>, or <b>12.3%</b>. But the gain varies by season:',9.5,13,limit=40)
 for i,(period,fold) in enumerate([('APR-MAY',1),('JUN-JUL',2),('AUG-SEP',3),('OCT-DEC',4)]):
  x=36+i*139;a=next(z for z in FORWARD if z['role']=='No weather' and int(z['fold'])==fold);b=next(z for z in FORWARD if z['role']=='Morning weather' and int(z['fold'])==fold)
  c=TEAL if val(b,'RMSE')<val(a,'RMSE') else ORANGE
  r.text(x,692,period,7.5,'Bold',MUTED);r.text(x,711,f"{val(a,'RMSE'):.1f} → {val(b,'RMSE'):.1f}",16,'Bold',c)
 r.text(36,735,'Airport-average → morning-weather RMSE, minutes. Each window is later than its training data.',7,'Sans',MUTED)

def tuning(r):
 r.start('Model specification + tuning')
 r.title('03 / SELECT BEFORE TESTING','A restrained forest wins.', 'The selected model averages 500 trees, considers all 22 predictors at a split, and stops splitting nodes smaller than 30 observations. All tuning uses 2023 only.')
 r.para(36,181,540,'Inputs cover airport, weekday, annual seasonality, afternoon schedule size, route distance, long-haul and evening shares, carrier mix, and early weather. Penalized regressions also receive quadratic terms, numeric interactions and airport interactions. Imputation and scaling are fitted separately inside each training fold. There are <b>828 candidate configurations</b> across the two information sets, plus four fixed baselines.',9.5,13,limit=65)
 r.text(36,266,'Training fit improves. Future-like validation does not.',13,'Bold')
 r.text(36,289,'Forest with weather • all 22 predictors available at each split',8.5,'Sans',MUTED)
 vals=sorted([z for z in GRID if z['set']=='Weather' and z['family']=='Forest' and val(z,'mtry')==22],key=lambda z:-val(z,'leaf'))
 x0,x1=73,561;y0,y1=325,478;xx=lambda i:x0+i*(x1-x0)/(len(vals)-1);yy=lambda v:y1-v/40*(y1-y0)
 for t in [0,10,20,30,40]:r.line(x0,yy(t),x1,yy(t));r.text(61,yy(t)-4,str(t),8,'Sans',MUTED,'right')
 for key,color in [('RMSE',ORANGE),('train_RMSE',TEAL)]:
  for i in range(len(vals)-1):r.line(xx(i),yy(val(vals[i],key)),xx(i+1),yy(val(vals[i+1],key)),color,2)
  for i,z in enumerate(vals):r.dot(xx(i),yy(val(z,key)),3,color)
 for i,z in enumerate(vals):r.text(xx(i),488,z['leaf'],8,'Sans',MUTED,'center')
 best=min(range(len(vals)),key=lambda i:val(vals[i],'RMSE'));r.dot(xx(best),yy(val(vals[best],'RMSE')),6,ORANGE,True)
 r.text(xx(best),yy(val(vals[best],'RMSE'))-21,'SELECTED / 26.18',8,'Bold',ORANGE,'center')
 r.text(73,511,'Minimum node size: large → small / increasing flexibility',8,'Bold')
 r.text(370,315,'Validation',8,'Bold',ORANGE);r.text(478,315,'Training',8,'Bold',TEAL)
 r.text(36,552,'The search did not stop at depth 6.',13,'Bold')
 r.para(36,579,259,'<b>Tree:</b> 18 depths, up to 30, crossed with four leaf sizes. The best weather tree uses depth 3.<br/><br/><b>Forest:</b> four predictor counts crossed with seven node sizes, including very shallow trees.',9.5,13,limit=105)
 r.para(317,579,259,'<b>Ridge / LASSO / elastic net:</b> 61 penalties from 0.001 to 1,000,000 and five mixing values.<br/><br/><b>KNN:</b> nine neighbor counts, from 3 to 240. Boundary optima triggered wider grids before evaluation.',9.5,13,limit=105)
 r.note(705,'The January 2024 outcomes played no role in choosing the method, settings or benchmark. All models were fitted on the full 2023 development sample, and their future predictions were saved before evaluation outcomes were joined.')

def future(r):
 r.start('The future test')
 r.title('04 / JANUARY 2024 · 31 DATES · 93 AIRPORT-DAYS','January breaks the winning streak.','Morning weather does not lower future RMSE. Against the airport average, MAE falls from 15.12 to 13.98 minutes, but the largest delays go largely unanticipated. Three dates account for 69.5% of its squared error.')
 # Three aligned time series expose the correlated misses, rather than hiding them in a score.
 x0,x1=73,400;xx=lambda day:x0+(day-1)/30*(x1-x0)
 for j,ap in enumerate(['EWR','JFK','LGA']):
  top=197+j*112;bottom=top+78;yy=lambda v:bottom-v/130*78
  r.text(36,top-18,ap,11,'Bold')
  for t in [0,60,120]:r.line(x0,yy(t),x1,yy(t));r.text(x0-8,yy(t)-3,str(t),7,'Sans',MUTED,'right')
  z=sorted([v for v in EV if v['origin']==ap],key=lambda v:v['date'])
  for key,c in [('delay',INK),('Morning weather',ORANGE)]:
   for a,b in zip(z,z[1:]):r.line(xx(int(a['date'][-2:])),yy(val(a,key)),xx(int(b['date'][-2:])),yy(val(b,key)),c,1.5)
  if ap=='LGA':
   for day in [16,19]:
    a=z[day-1];r.dot(xx(day),yy(val(a,'delay')),3,INK)
   r.text(430,top+2,'JAN 16 / LGA',8,'Bold',ORANGE)
   r.text(430,top+22,'120 min',21,'Bold')
   r.text(430,top+51,'Predicted: 20 min',8,'Sans',MUTED)
  if ap=='EWR':
   r.text(430,top,'DAILY MEAN DELAY',7,'Bold',MUTED)
   r.line(430,top+28,450,top+28,INK,1.8);r.text(458,top+24,'Observed',8)
   r.line(430,top+49,450,top+49,ORANGE,1.8);r.text(458,top+45,'9 a.m. forecast',8)
  if ap=='JFK':
   r.para(430,top,146,'The same difficult dates hit multiple airports. Uncertainty must keep those shared shocks together.',9,12,limit=80)
 for day in [1,8,16,24,31]:r.text(xx(day),510,f'Jan {day}',7.5,'Sans',MUTED,'center')
 r.line(36,540,576,540,INK,1)
 for x,n,l in [(36,'20.76','AIRPORT-MEAN RMSE'),(221,'20.89','WEATHER-FOREST RMSE'),(406,'13.98','WEATHER-FOREST MAE')]:
  r.text(x,558,n,29,'Bold',ORANGE if x==221 else INK);r.text(x,598,l,7.3,'Bold',MUTED)
 r.para(36,629,259,'<b>No demonstrated RMSE gain.</b> The change is <b>-0.14 minutes</b> of improvement. A paired seven-day block bootstrap gives a 95% interval of <b>-1.44 to +1.70 minutes</b>. The fixed-family forest comparison also straddles zero.',9.5,13,limit=90)
 r.para(317,629,259,'<b>Decision:</b> do not replace the simple benchmark on this evidence. Test more seasons and add forecasts of afternoon weather and network disruption. January has only 31 dates; its 1,025 missing departure outcomes are another blind spot.',9.5,13,limit=90)
 r.note(719,'Intervals use 2,000 resamples of seven-day blocks, keeping all airports together and the fitted models fixed. RMSE is in minutes of airport-day mean delay, not individual passenger delay. Lower is better.')

def appendix(r):
 for name in ['PROTOCOL.md','download.py','prepare.R','methods.R','select.R','lock.R','evaluate.R','describe.R','finish.R','example.Rmd','render.R','reproduce.R','report.py']:
  expanded=[]
  for no,line in enumerate((ROOT/name).read_text().splitlines(),1):
   for k,s in enumerate(textwrap.wrap(line,100,replace_whitespace=False,drop_whitespace=False) or ['']):expanded.append((f'{no:4}  ' if k==0 else '      ')+s)
  for offset in range(0,len(expanded),68):
   r.start('Complete source');r.text(36,65,name,18,'Bold');r.text(576,72,f'Part {offset//68+1}',8,'Sans',MUTED,'right')
   for j,line in enumerate(expanded[offset:offset+68]):r.text(36,103+j*9.3,line,7.8,'Mono')
 r.start('Evidence + provenance')
 r.title('REPRODUCIBILITY','Open the whole analysis.','The archive includes raw source snapshots, complete grids, paired validation predictions, frozen future predictions, evaluation results and audit checks.')
 y=187
 for title,url in [('2023 flights / nycflights23','https://moderndive.github.io/nycflights23/'),('2024 flights / BTS monthly records','https://www.transtats.bts.gov/PREZIP/'),('Hourly weather / IEM','https://mesonet.agron.iastate.edu/request/download.phtml'),('Timestamp construction / upstream source','https://github.com/simonpcouch/anyflights/blob/main/R/utils.R')]:
  r.text(36,y,title,11,'Bold',BLUE);r.text(36,y+20,url,8,'Sans',MUTED);r.c.linkURL(url,(36,792-y-36,576,792-y),relative=0);y+=65
 r.para(36,477,540,'<b>Time handling matters.</b> The upstream flight package copies local scheduled hours into a UTC-tagged timestamp without conversion. We use the original local calendar fields and scheduled HHMM values instead. Weather for both years was retrieved with explicit America/New_York output. The source code and cutoff checks make this choice inspectable.',10,14,limit=95)
 r.para(36,588,540,'<b>Render:</b> run Rscript render.R. <b>Rebuild:</b> run Rscript reproduce.R. Both report editions come from the same parameterized R Markdown source. The code edition appends every analysis and layout script. Rerunning a saved evaluation reproduces it; it does not make it unopened again. SHA256SUMS verifies the delivered files.',10,14,limit=95)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--code',action='store_true');args=p.parse_args()
 r=Report(args.output)
 for page in [opening,patterns,validation,tuning,future]:page(r)
 if args.code:appendix(r)
 r.save()
