suppressPackageStartupMessages(library(tidyverse))
d<-readRDS('data/development.rds') %>% mutate(month=as.integer(format(date,'%m')),
 quarter=paste0('Q',ceiling(month/3)),rough=visibility_min<3|wind_max>=20,
 condition=if_else(rough,'Low visibility / high wind','Other mornings'))
write.csv(d,'results/development-visuals.csv',row.names=FALSE)
# Predefined weather cutoffs: minimum visibility <3 miles or max wind >=20 knots.
# Descriptive contrasts are not causal effects; show all airport-quarter cells.
contrasts<-d %>% filter(!is.na(rough)) %>% group_by(origin,quarter,rough) %>%
 summarize(n=n(),mean=mean(delay),median=median(delay),lo=quantile(delay,.25),hi=quantile(delay,.75),.groups='drop')
write.csv(contrasts,'results/weather-contrasts.csv',row.names=FALSE)
monthly<-d %>% group_by(origin,month) %>% summarize(mean=mean(delay),median=median(delay),lo=quantile(delay,.25),hi=quantile(delay,.75),.groups='drop')
write.csv(monthly,'results/monthly.csv',row.names=FALSE)
