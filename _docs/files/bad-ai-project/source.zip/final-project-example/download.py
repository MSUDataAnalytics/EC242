"""Optional refresh of public source snapshots. Bundled files suffice to reproduce.
Refreshing may change upstream data; use SHA256SUMS to retain the delivered version.
"""
from pathlib import Path
from urllib.request import urlretrieve
from urllib.parse import urlencode
root=Path(__file__).resolve().parent/'data';root.mkdir(exist_ok=True)
urlretrieve('https://raw.githubusercontent.com/moderndive/nycflights23/main/data/flights.rda',root/'flights-2023.rda')
urlretrieve('https://www.transtats.bts.gov/PREZIP/On_Time_Reporting_Carrier_On_Time_Performance_1987_present_2024_1.zip',root/'bts-2024-01.zip')
params=[('station',s) for s in ['EWR','JFK','LGA']]+[('data',v) for v in ['tmpf','relh','sknt','p01i','vsby','mslp']]+list(dict(sts='2023-01-01T05:00:00Z',ets='2024-02-01T05:00:00Z',tz='America/New_York',format='onlycomma',latlon='no',elev='no',missing='M',trace='0.0001',direct='no',report_type='3').items())
urlretrieve('https://mesonet.agron.iastate.edu/cgi-bin/request/asos.py?'+urlencode(params),root/'iem-hourly.csv')
urlretrieve('https://raw.githubusercontent.com/simonpcouch/anyflights/main/R/utils.R',root/'upstream-anyflights-utils.R')
