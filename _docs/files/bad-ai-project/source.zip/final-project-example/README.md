# The 9 a.m. forecast

Instructor-created EC242 final project showcase. Five report pages, plus a matching complete-code edition. This revision replaces the earlier same-day, random-holdout example.

## The question and the answer

At 9 a.m. in New York, can airport planners anticipate the mean departure delay of flights scheduled from noon through 23:59? Does weather observed before 8 a.m. help beyond information about the calendar and flight schedule?

Morning weather helps in 2023 forward validation: the selected forest has 26.18 minutes RMSE, versus 29.84 for the best no-weather choice (airport averages), a 12.3% reduction. It does not establish a gain in the later January 2024 test: 20.89 versus 20.76 minutes RMSE. The paired seven-day block-bootstrap interval for baseline-minus-model RMSE is -1.44 to +1.70 minutes. Separately tuned forests with and without weather also show no clear future advantage (+0.14 minutes improvement; interval -1.23 to +1.19).

This is a completed negative generalization result, not an invitation to tune against January. The January outcomes were opened only after predictions were locked. No model settings were changed afterward. The report makes the large misses visible and concludes that the evidence does not justify replacing the benchmark. A good scientific project need not produce a winning model; it must make the test credible and the conclusion follow from it.

## Sources and time handling

1. [2023 flights, nycflights23](https://moderndive.github.io/nycflights23/reference/flights.html), sourced from BTS via anyflights. Raw snapshot: https://raw.githubusercontent.com/moderndive/nycflights23/main/data/flights.rda
2. [January 2024 BTS Reporting Carrier records](https://www.transtats.bts.gov/PREZIP/On_Time_Reporting_Carrier_On_Time_Performance_1987_present_2024_1.zip). This independent later period was selected in the written protocol before retrieval. It was not used in the previous example.
3. [Iowa Environmental Mesonet airport observations](https://mesonet.agron.iastate.edu/request/download.phtml), routine hourly reports for EWR, JFK and LGA, January 2023 through January 2024. The same query and units serve both periods. Source query is saved in download.py.

Downloaded November 10, 2026. Source snapshots are bundled; SHA256SUMS verifies the supplied files.

**A timestamp trap was corrected.** The upstream anyflights code copies BTS local scheduled departure times into a UTC-tagged `time_hour` without conversion. The package documentation's UTC label does not make those local clock values UTC instants. See the bundled upstream source and [get_flight_data in utils.R](https://github.com/simonpcouch/anyflights/blob/main/R/utils.R). This study uses the original flight calendar fields and scheduled HHMM as New York local time. Weather is newly retrieved with explicit America/New_York output. The earlier example's schedule-share features shifted these clock values incorrectly; those results are superseded.

Both flight periods use Reporting_Airline definitions and contain the same 14 carriers. We retain scheduled afternoon flights with missing departure outcomes in schedule counts, excluding those outcomes only from the target mean. The data contains 1,095 development and 93 future airport-days. No airport-day is dropped. There are 262,528 development afternoon flights (8,180 missing delay outcomes) and 19,359 future scheduled afternoon flights (1,025 missing outcomes). This model does not estimate cancellation risk. Weather trace values remain 0.0001 inches, never silently zero. Negative rain/visibility and impossible wind readings become missing. Training-only medians handle missing predictor readings.

## A credible prediction clock

Predictors: airport, weekday, sine/cosine of season, scheduled afternoon volume, average route distance, long-haul and evening shares, selected carrier shares, and optionally weather recorded from midnight through 07:59. No realized flight delay, cancellation count, actual departure time, or afternoon weather is a predictor. The one-hour buffer makes the 9 a.m. cutoff conservative, but archived observation time is not proof of real-time receipt. Schedule revisions and final-record availability are also untested. Treat this as a historical feasibility test, not a deployed operational tool.

Validation always points forward:

| Round | Training | Validation |
|---|---|---|
| 1 | Jan-Mar 2023 | Apr-May 2023 |
| 2 | Jan-May 2023 | Jun-Jul 2023 |
| 3 | Jan-Jul 2023 | Aug-Sep 2023 |
| 4 | Jan-Sep 2023 | Oct-Dec 2023 |

All airports on a date stay together. Fold-local preprocessing learns medians and scaling from the training portion only. The rich penalized-regression specification adds numeric squares, pairwise numeric interactions and airport-numeric interactions. Each of six model families is separately tuned with and without morning weather. There are 828 candidate configurations and four fixed baselines (3,328 fold fits). Grids were widened using development results when optima touched the initial boundaries; trees reach depth 30. The winning forest uses 500 trees, 22 candidate predictors per split, and minimum node size 30. The best no-weather forest uses minimum node size 60 and 11 candidate predictors per split.

The strongest no-weather choice is permitted to be a simple baseline. This avoids inflating the weather gain by forcing comparison with a weaker tuned method. The fixed-family forest ablation provides a second check that isolates the addition of weather while allowing both versions to tune fairly. These are predictive information comparisons, not causal effects of changing weather.

The final evaluation is a contiguous later month: January 2024, 31 dates and 93 airport-days (7.8% of the combined panel). This intentionally differs from the assignment's usual random ~10% split to test time transfer. It is one winter month, not an all-season performance guarantee. We resample seven-day moving blocks, retaining all airports on a date, for 2,000 paired bootstrap replicates. Few independent weeks mean uncertainty remains substantial. Intervals hold the fitted models fixed and do not cover selection uncertainty, other years, or all possible serial dependence.

## Reproduce

R: tidyverse, glmnet, rpart, ranger, FNN, jsonlite, rmarkdown, knitr. Python: reportlab. Pandoc is required for the R Markdown driver; LaTeX is not. The renderer embeds Arial, Georgia and Courier New when available and otherwise uses PDF base fonts. `session-info.txt` records R versions.

```sh
# Install once if needed:
Rscript -e 'install.packages(c("tidyverse","glmnet","rpart","ranger","FNN","jsonlite","rmarkdown","knitr"))'
python3 -m pip install -r requirements-design.txt

# Render both editions from saved, audited results:
PYTHON=python3 Rscript --vanilla render.R

# Full deterministic rebuild from bundled raw snapshots:
PYTHON=python3 Rscript --vanilla reproduce.R

# Audit and diagnostic exports, without model fitting:
Rscript --vanilla finish.R
```

Both editions use the same parameterized example.Rmd. Its render chunk calls report.py for vector layout. With code on, the complete analysis and layout scripts are appended with line numbers. The first five report pages are identical. This custom rendering route is documented rather than presented as ordinary default LaTeX output.

The chronological pipeline is `prepare.R` → `select.R` → `lock.R` → `evaluate.R` → `describe.R` → `finish.R` → `render.R`. `PROTOCOL.md` records the initial design and development-only amendments. Selection and prediction hashes are saved before `evaluate.R` reads the quarantined labels. These are integrity checks, not externally certified timestamps. Rerunning the pipeline reproduces an already-seen evaluation; it does not create a fresh one.

The CSV exports include the full grid, fold scores, every validation prediction, paired chosen-model predictions, the future trajectories and uncertainty replicates. `finish.R` checks temporal separation, complete grids, baseline construction and unchanged locks. The delivered RMSEs were also independently recalculated in Python.

## Reading the visuals

The report follows one argument: afternoon delay clusters by season; morning weather associations vary within airport and quarter; weather helps several tuned models in forward development tests; a later month exposes severe common-date misses. The calendar includes every development airport-day, the weather contrasts include reversals and sparse counts, and future traces show every evaluation date. Color and shape jointly distinguish comparisons. Values above 90 minutes are capped only in the calendar's color scale, explicitly labeled 90+; model fitting and error calculations retain the full outcomes.

Do not describe the 2023 development results as untouched external evidence. That year has appeared in earlier analysis. January 2024 is the genuinely new out-of-time evaluation. The previous PDF is retained separately for provenance but should not be distributed as the current showcase.
