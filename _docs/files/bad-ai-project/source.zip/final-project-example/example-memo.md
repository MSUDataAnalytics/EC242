At 09:00, can morning weather improve predictions of afternoon departure
delay? The report uses 2023 for forward validation and January 2024 for
a locked future evaluation. The rendered report reads audited results;
document changes cannot silently change the selected model or evaluation
sample.

The vector renderer supplies identical report pages in both editions.
When code is on, it appends the complete analysis and rendering scripts
with line numbers. All raw data and computed results are supplied in the
source archive.
