suppressPackageStartupMessages(library(tidyverse))
d<-readRDS('data/development.rds');x<-readRDS('data/evaluation-features.rds');e<-read.csv('results/evaluation.csv',check.names=FALSE)%>%mutate(date=as.Date(date))
lock<-read.csv('results/selection-lock.csv');v<-read.csv('results/validation-predictions.csv');fold<-read.csv('results/fold-scores.csv');reg<-read.csv('results/configurations.csv')
# Extract paired predictions using choices fixed before evaluation.
p<-map_dfr(1:nrow(lock),function(i){z<-lock[i,];v%>%filter(set==z$set,id==z$id)%>%mutate(role=z$role)})
write.csv(p,'results/chosen-validation-predictions.csv',row.names=FALSE)
f<-p%>%group_by(role,fold)%>%summarize(n=n(),RMSE=sqrt(mean((observed-predicted)^2)),.groups='drop')
write.csv(f,'results/forward-comparison.csv',row.names=FALSE)
daily<-e%>%group_by(date)%>%summarize(mean_observed=mean(delay),mean_predicted=mean(`Morning weather`),
 sse=sum((delay-`Morning weather`)^2),baseline_sse=sum((delay-`No weather`)^2),.groups='drop')
write.csv(daily,'results/future-daily.csv',row.names=FALSE)
worst<-e%>%mutate(error=`Morning weather`-delay)%>%arrange(desc(abs(error)))
write.csv(head(worst,6),'results/worst-errors.csv',row.names=FALSE)
jsonlite::write_json(list(configurations=nrow(reg),fold_fits=nrow(fold),
 validation_no=lock$RMSE[1],validation_weather=lock$RMSE[2],
 validation_gain=100*(1-lock$RMSE[2]/lock$RMSE[1]),
 top3_dates_sse_share=sum(sort(daily$sse,decreasing=TRUE)[1:3])/sum(daily$sse),
 morning_weather_days=sum(with(d,visibility_min<3|wind_max>=20),na.rm=TRUE)),
 'results/findings.json',auto_unbox=TRUE,pretty=TRUE,digits=8)
# Check splits, paired baseline construction, complete grids and frozen hashes.
stopifnot(nrow(d)==1095,nrow(x)==93,max(d$date)<min(x$date),
 all(table(x$date)==3),!any(c('delay','missing_outcomes')%in%names(x)),
 all(table(interaction(fold$set,fold$id,drop=TRUE))==4),
 !anyDuplicated(reg[c('set','id')]))
means<-tapply(d$delay,d$origin,mean)
stopifnot(max(abs(e$`No weather`-means[e$origin]))<1e-10)
h<-readLines('results/before-evaluation-hashes.txt')
stopifnot(h[1]==paste('protocol',tools::md5sum('PROTOCOL.md')),
 h[2]==paste('selection',tools::md5sum('results/selection-lock.csv')),
 h[3]==paste('predictions',tools::md5sum('results/locked-predictions.csv')))
for(i in 1:nrow(lock)){
 z<-lock[i,];o<-filter(p,role==z$role)
 stopifnot(abs(sqrt(mean((o$observed-o$predicted)^2))-z$RMSE)<1e-9)
}
writeLines(c('PASS: all training dates precede every future date.',
 'PASS: complete four-fold grid; no duplicated candidate keys.',
 'PASS: no future outcome or missing-outcome-count feature.',
 'PASS: future baseline equals development-only airport means.',
 'PASS: selection and prediction locks unchanged after evaluation.',
 'PASS: pooled validation metrics recomputed from paired predictions.'),'results/audit.txt')
print(readLines('results/audit.txt'))
