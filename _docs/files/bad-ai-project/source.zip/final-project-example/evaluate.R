suppressPackageStartupMessages(library(tidyverse))
stopifnot(file.exists('results/before-evaluation-hashes.txt'))
p<-read.csv('results/locked-predictions.csv',check.names=FALSE)%>%mutate(date=as.Date(date))
e<-left_join(p,readRDS('data/evaluation-labels.rds'),by=c('origin','date'),relationship='one-to-one')
stopifnot(nrow(e)==93,!anyNA(e$delay))
roles<-c('No weather','Morning weather','Forest without weather','Forest with weather')
score<-function(d,col)sqrt(mean((d$delay-d[[col]])^2))
s<-map_dfr(roles,function(v)tibble(role=v,RMSE=score(e,v),MAE=mean(abs(e$delay-e[[v]]))))
write.csv(e,'results/evaluation.csv',row.names=FALSE);write.csv(s,'results/evaluation-scores.csv',row.names=FALSE)
a<-e%>%group_by(origin)%>%summarize(no_weather=sqrt(mean((delay-`No weather`)^2)),weather=sqrt(mean((delay-`Morning weather`)^2)),MAE=mean(abs(delay-`Morning weather`)),.groups='drop')
write.csv(a,'results/airport-errors.csv',row.names=FALSE)
set.seed(2422025);dates<-sort(unique(e$date));n<-length(dates)
boot<-map_dfr(1:2000,function(i){starts<-sample(1:(n-6),ceiling(n/7),replace=TRUE);ix<-unlist(lapply(starts,function(s)s:(s+6)))[1:n];ix<-unlist(lapply(dates[ix],function(t)which(e$date==t)));z<-e[ix,];b<-score(z,'No weather');m<-score(z,'Morning weather');f<-score(z,'Forest without weather');g<-score(z,'Forest with weather');tibble(gain=b-m,percent=100*(1-m/b),forest_gain=f-g,model_rmse=m)})
write.csv(boot,'results/block-bootstrap.csv',row.names=FALSE)
jsonlite::write_json(list(model_rmse=s$RMSE[2],no_weather_rmse=s$RMSE[1],mae=s$MAE[2],
 gain=s$RMSE[1]-s$RMSE[2],gain_percent=100*(1-s$RMSE[2]/s$RMSE[1]),
 gain_interval=quantile(boot$gain,c(.025,.975)),percent_interval=quantile(boot$percent,c(.025,.975)),
 forest_gain=s$RMSE[3]-s$RMSE[4],forest_gain_interval=quantile(boot$forest_gain,c(.025,.975)),
 missing_outcomes=sum(e$missing_outcomes),mean_delay=mean(e$delay)),
 'results/evaluation-summary.json',pretty=TRUE,auto_unbox=TRUE,digits=8)
print(s);print(a);print(quantile(boot$percent,c(.025,.975)))
