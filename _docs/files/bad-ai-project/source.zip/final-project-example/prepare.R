suppressPackageStartupMessages(library(tidyverse))
# BTS CRSDepTime is LOCAL clock time. anyflights copies it into a UTC-tagged
# POSIXct without conversion; do not shift that clock by a timezone offset.
e<-new.env();load('data/flights-2023.rda',e)
f<-e$flights %>% mutate(date=as.Date(sprintf('%04d-%02d-%02d',year,month,day)),
 hour=sched_dep_time%/%100) %>% select(origin,date,hour,dep_delay,distance,carrier)
# Extract only NYC records from the official future-period file. Its outcomes
# are aggregated and quarantined, not printed or used in model selection.
z<-unzip('data/bts-2024-01.zip',list=TRUE);name<-z$Name[which.max(z$Length)]
con<-unz('data/bts-2024-01.zip',name)
g<-read_csv(con,col_types=cols(.default=col_skip(),Origin=col_character(),FlightDate=col_date(),
 CRSDepTime=col_double(),DepDelay=col_double(),Distance=col_double(),Reporting_Airline=col_character()),progress=FALSE) %>%
 filter(Origin%in%c('EWR','JFK','LGA')) %>%
 transmute(origin=Origin,date=FlightDate,hour=CRSDepTime%/%100,dep_delay=DepDelay,distance=Distance,carrier=Reporting_Airline)
stopifnot(all(g$date>=as.Date('2024-01-01')&g$date<=as.Date('2024-01-31')),
 all(g$carrier%in%unique(f$carrier)))
f<-bind_rows(f,g)
avg<-function(x)if(all(is.na(x)))NA_real_ else mean(x,na.rm=TRUE)
low<-function(x)if(all(is.na(x)))NA_real_ else min(x,na.rm=TRUE)
high<-function(x)if(all(is.na(x)))NA_real_ else max(x,na.rm=TRUE)
a<-f %>% filter(hour>=12,hour<24) %>% group_by(origin,date) %>% summarize(
 delay=avg(dep_delay),scheduled=n(),distance=avg(distance),longhaul=mean(distance>=1500),
 evening=mean(hour>=17),share_ua=mean(carrier=='UA'),share_b6=mean(carrier=='B6'),
 share_dl=mean(carrier=='DL'),missing_outcomes=sum(is.na(dep_delay)),.groups='drop')
w<-read_csv('data/iem-hourly.csv',na=c('M','','NA'),show_col_types=FALSE,
 col_types=cols(station=col_character(),valid=col_character(),.default=col_double())) %>%
 mutate(date=as.Date(substr(valid,1,10)),hour=as.integer(substr(valid,12,13)))
# Keep routine records exactly once. Clock strings are requested in New York
# local time; 00:00-07:59 never overlaps the noon-or-later target window.
w<-w %>% distinct() %>% mutate(sknt=if_else(sknt<0|sknt>174,NA_real_,sknt),
 p01i=if_else(p01i<0,NA_real_,p01i),vsby=if_else(vsby<0,NA_real_,vsby))
m<-w %>% filter(hour<8) %>% group_by(origin=station,date) %>% summarize(temp=avg(tmpf),
 humidity=avg(relh),wind=avg(sknt),wind_max=high(sknt),rain=avg(p01i),rain_max=high(p01i),
 visibility=avg(vsby),visibility_min=low(vsby),pressure=avg(mslp),weather_hours=n(),.groups='drop')
stopifnot(!anyDuplicated(a[c('origin','date')]),!anyDuplicated(m[c('origin','date')]))
d<-left_join(a,m,by=c('origin','date'),relationship='one-to-one') %>% mutate(
 origin=factor(origin,levels=c('EWR','JFK','LGA')),weekday=factor(as.POSIXlt(date)$wday,levels=0:6),
 sin_year=sin(2*pi*as.numeric(format(date,'%j'))/365.25),cos_year=cos(2*pi*as.numeric(format(date,'%j'))/365.25),
 weather_missing=as.integer(is.na(weather_hours)))
stopifnot(nrow(d)==nrow(a),!anyNA(d$delay),nrow(d)==396*3)
dev<-filter(d,date<as.Date('2024-01-01'));ev<-filter(d,date>=as.Date('2024-01-01'))
saveRDS(dev,'data/development.rds');saveRDS(select(ev,origin,date,delay,missing_outcomes),'data/evaluation-labels.rds')
saveRDS(select(ev,-delay,-missing_outcomes),'data/evaluation-features.rds')
write.csv(dev,'results/development.csv',row.names=FALSE)
jsonlite::write_json(list(development_rows=nrow(dev),future_rows=nrow(ev),
 development_flights=sum(dev$scheduled),future_scheduled=sum(ev$scheduled),
 missing_development=sum(dev$missing_outcomes),mean=mean(dev$delay),median=median(dev$delay),
 missing_weather=sum(is.na(d$weather_hours)),weather_records=nrow(w),
 source_carriers_2023=sort(unique(e$flights$carrier)),source_carriers_2024=sort(unique(g$carrier))),
 'results/data-audit.json',auto_unbox=TRUE,pretty=TRUE)
cat('Prepared',nrow(dev),'development rows and',nrow(ev),'future features. No future outcomes displayed.\n')
