# Protocol fixed before future-period retrieval and afternoon-target modeling

Question: At 09:00 New York time, can airport planners anticipate the mean departure delay among flights scheduled from noon through 23:59 that day? Does pre-09:00 local weather improve predictions beyond calendar and schedule information?

Use 2023 as development; January 2024 is the fixed future evaluation period, selected before retrieval. This is a one-month winter transfer test, not an all-season guarantee. Previous work inspected 2023 daily outcomes, so validation there is development evidence only. January 2024 outcomes will be quarantined until model choices and predictions are locked.

Inputs available by 09:00: airport, day of week, annual sine/cosine, scheduled afternoon flights and route mix, and weather observations from 00:00 through strictly before 08:00 (one-hour reporting buffer). Schedules are reconstructed from final flight records; historical schedule revisions and weather-feed latency cannot be audited. No realized flight-delay input, cancellations, actual departure time, or weather at/after 08:00 enters a predictive model.

Target: mean departure delay among flights scheduled noon-23:59 with observed departure delay. Retain missing outcomes in schedule counts and report coverage; do not impute targets. Exclude no airport-day unless every afternoon outcome is missing. Local dates and scheduled hours define target membership.

Sources: 2023 nycflights23 flight records, 2024 BTS Reporting Carrier monthly file. Download IEM routine hourly airport weather for both periods to use identical time cutoffs, units and observation definitions. Check carrier population against the 2023 snapshot and disclose any source-coverage difference.

Forward validation: train Jan-Mar 2023, validate Apr-May; train Jan-May, validate Jun-Jul; train Jan-Jul, validate Aug-Sep; train Jan-Sep, validate Oct-Dec. No future observations enter a training fold. Select hyperparameters by pooled validation RMSE. All airports on one day remain together. Fold-local imputation/scaling.

Baselines: global mean, airport mean, airport-weekday mean, schedule/calendar OLS. Candidate families: ridge, LASSO, elastic net, KNN, regression tree (depths through 30), random forest. Compare two input sets: calendar/schedule alone and the same inputs plus morning weather. Tune each on the same forward folds. The primary weather increment compares the best separately tuned model for each input set; a paired fixed-family forest ablation is also reported to distinguish information from algorithm choice. No causal interpretation of weather effects.

Lock all selected model settings, baseline and future predictions before joining evaluation outcomes. Refit on all 2023 data with fixed seeds. Evaluate once on January 2024. Report RMSE, MAE, baseline-relative improvement, weather increment, per-airport results, daily error trajectory and largest misses. Use paired 7-day moving-block bootstrap across January dates (2,000 replicates), retaining all airports per sampled date; acknowledge only 31 evaluation dates and few independent weeks. No tuning after evaluation, even if weather adds nothing or hurts.

The final report should answer the operational question, not manufacture a positive result. Retrospective weather associations are development-only and must not be mistaken for causal effects or future predictors.

Source verification before selection: upstream anyflights copies BTS local CRS departure clocks into a UTC-tagged timestamp without converting them. This rebuild uses the original year/month/day and scheduled HHMM fields as local clock values, matching the direct BTS file. The prior daily example's schedule-share features were shifted incorrectly; those results are superseded. Weather for both years is newly retrieved with explicit America/New_York output. Trace precipitation remains 0.0001 inches; it is not treated as missing or exactly zero.

Development-only grid expansion: initial optima reached the largest penalty, largest forest minimum-node size, and largest KNN neighbor count for some families. Before opening future outcomes, expand penalties through 1,000,000; forest minimum-node sizes through 270 (the entire first training sample); and KNN through 240 neighbors (below the first training sample size). For the main operational comparison, allow the best fixed baseline to win the no-weather competition rather than force a weaker tuned model. Retain the fixed-family forest comparison as the weather-information check.
